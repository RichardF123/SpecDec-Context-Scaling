SpecDec Phase 1 + Phase 2 Optimization Suite
==============================================

What this package does
----------------------
It runs the two requested stages IN ORDER on the current final
feat/paged-attention-v1 codebase.

PHASE 1 — H2O execution optimization

The H2O POLICY is not changed.

A. Kernel-integrated H2O score capture
   - current reference path:
       materialize K -> kv_repeat -> torch matmul -> softmax -> mean heads
   - experimental path:
       direct paged attention kernel -> after final online-softmax normalizer,
       revisit paged K once -> emit normalized global-token mass
   - removes full-K materialization and the extra framework-level matmul/softmax.
   - IMPORTANT: this is kernel-integrated score capture, but it still performs
     one additional QK revisit to emit per-token probabilities. It is NOT
     falsely described as a zero-extra-QK single-pass fusion.

B. Page-native H2O compaction
   - current reference path:
       materialize -> gather -> repack pages
   - experimental path:
       keep_indices -> direct page-to-page CUDA copy
   - selection policy and retained-token ordering are unchanged.

Correctness gates run BEFORE latency:
   - BF16 compaction payload exactness
   - V-FP8 K/V/scale compaction exactness
   - real SpecDec H2O reference vs optimized:
       generated tokens
       SpecDec stats
       retained positions

If a correctness gate fails, the suite STOPS before performance claims.

The H2O benchmark then compares:
   standard direct SpecDec
   reference H2O
   optimized H2O
at 512 / 2K / 4K / 8K, BF16 and V-FP8 target, H2O50, 3 repeats.
At 2K and 8K it also measures score-only and compaction-only paths so the
speedup can be attributed to the two execution hotspots.

PHASE 2 — Flash-style / tiled online-softmax attention

Technical correction:
The current final direct PagedAttention kernel ALREADY uses online softmax.
Its weakness is that it is a warp-per-query, largely serial traversal over the
KV sequence rather than a tiled Flash-style implementation.

Therefore this suite does NOT pretend to invent a new online-softmax kernel.
It uses the repository's existing Triton tiled online-softmax attention as the
mature contiguous baseline and measures:
   q_len = 1 / 2 / 3 / 4
   context = 512 / 2K / 4K / 8K
   target-like D128 and draft-like D64 GQA shapes

Compared paths:
   contiguous CUDA online-softmax kernel
   contiguous Triton tiled online-softmax kernel
   current direct PagedAttention
   paged -> materialize -> CUDA end-to-end
   paged -> materialize -> Triton end-to-end

Primary gate:
For target-like q_len=4 verification, materialize+Triton must be at least 1.10x
faster than current paged-direct on at least 2 of {2K,4K,8K}, while staying
within the correctness tolerance. Only then does the suite automatically run a
real dual-model SpecDec Triton probe at 2K/4K/8K.

This deliberately avoids jumping directly to a Flash+Paged+H2O mega-kernel.

How to run
----------
Upload this ZIP to /workspace, then:

  cd /workspace/SpecDec-feat-paged-attention-v1
  unzip -o /workspace/specdec_phase12_optimization_suite.zip -d .
  chmod +x scripts/run_phase12_optimization_suite.sh
  bash scripts/run_phase12_optimization_suite.sh

The runner:
1. makes a backup of every core file it will patch;
2. applies the experimental execution-path patch;
3. rebuilds the CUDA extension;
4. runs H2O correctness gates;
5. runs H2O optimization benchmarks;
6. ensures a Torch-compatible Triton package is available;
7. runs q=1..4 tiled-attention microbenchmarks;
8. runs the real SpecDec Triton probe only if the q=4 gate passes;
9. packages all outputs.

Final archive:
  /workspace/SPECDEC_PHASE12_OPTIMIZATION_RESULTS_2026-10-04.zip

Backup / rollback
-----------------
The backup directory is written to:
  /workspace/SpecDec-feat-paged-attention-v1/.phase12_backup_path

To restore the pre-experiment core files:
  bash scripts/restore_phase12_backup.sh

Important scientific boundaries
--------------------------------
- H2O policy is frozen; only execution is changed.
- Any optimized H2O result is valid only if the reference-parity gate passes.
- Current PagedAttention already uses online softmax; Phase 2 is specifically
  about tiled/Flash-style execution efficiency.
- A Triton win is a baseline result, not a claim that Triton has already been
  integrated page-natively.
- Do not call the existing Triton baseline "our new FlashAttention".
- This package was syntax-checked here but cannot be CUDA/GPU-executed here;
  the included on-device gates are the source of truth.
