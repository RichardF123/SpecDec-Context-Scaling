#!/usr/bin/env bash
set -euo pipefail

REPO=/workspace/SpecDec-feat-paged-attention-v1
cd "$REPO"

export HF_HOME="${HF_HOME:-/root/hf-cache}"
export HF_HUB_CACHE="${HF_HUB_CACHE:-/root/hf-cache/hub}"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"

echo '============================================================'
echo ' SpecDec Phase 1 + Phase 2 Optimization Suite'
echo ' 1) H2O execution optimization'
echo ' 2) tiled Flash-style / online-softmax baseline'
echo '============================================================'

echo
echo '=== 0. Apply experimental patch (backup first) ==='
python tools/apply_phase12_patch.py
python -m pip install -e . --no-deps
rm -rf .cache/torch_extensions || true

echo
echo '=== 0b. Build CUDA extension smoke ==='
python - <<'PY'
from specdec.kernels.build import load
m=load()
needed=[
 'phase12_paged_attention_h2o_bf16',
 'phase12_paged_attention_h2o_vfp8',
 'phase12_paged_compact_bf16',
 'phase12_paged_compact_vfp8',
]
missing=[x for x in needed if not hasattr(m,x)]
if missing: raise SystemExit('missing CUDA APIs: '+repr(missing))
print('CUDA_EXTENSION_PHASE12: PASS')
PY

echo
echo '============================================================'
echo ' PHASE 1A — H2O correctness gate'
echo '============================================================'
python -m specdec.engine.h2o_execution_opt_gate

echo
echo '============================================================'
echo ' PHASE 1B — H2O reference vs optimized latency'
echo '============================================================'
python -m specdec.engine.h2o_execution_opt_bench \
  --contexts 512,2048,4096,8192 \
  --target-kvs base_bf16,v_fp8 \
  --repeats 3 --steps 16 --chunk 512 --page-size 16 \
  --outdir output/phase12_h2o_opt

echo
echo '============================================================'
echo ' PHASE 2A — ensure Triton'
echo '============================================================'
python tools/ensure_triton.py

echo
echo '============================================================'
echo ' PHASE 2B — tiled online-softmax q=1/2/3/4 microbenchmark'
echo '============================================================'
python -m specdec.engine.flash_tiled_microbench \
  --contexts 512,2048,4096,8192 \
  --qlens 1,2,3,4 --warmup 4 --iters 20 --repeats 3 \
  --outdir output/phase12_flash

echo
echo '============================================================'
echo ' PHASE 2C — gated real SpecDec probe'
echo '============================================================'
python -m specdec.engine.flash_specdec_probe

echo
echo '============================================================'
echo ' Package all results'
echo '============================================================'
python tools/package_phase12_results.py

echo
echo '============================================================'
echo ' PHASE12_SUITE_PASS'
echo '============================================================'
echo 'Download:'
echo '  /workspace/SPECDEC_PHASE12_OPTIMIZATION_RESULTS_2026-10-04.zip'
