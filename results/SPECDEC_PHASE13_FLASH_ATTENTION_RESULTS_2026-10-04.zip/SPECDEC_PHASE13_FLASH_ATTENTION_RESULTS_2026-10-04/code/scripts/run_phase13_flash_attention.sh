#!/usr/bin/env bash
set -euo pipefail

REPO=/workspace/SpecDec-feat-paged-attention-v1
cd "$REPO"

mkdir -p output/phase13_flash
LOG=output/phase13_flash/phase13_run.log
exec > >(tee "$LOG") 2>&1

echo "============================================================"
echo " SpecDec Phase13 — Page-native Flash-style PagedAttention"
echo "============================================================"

export HF_HOME="${HF_HOME:-/root/hf-cache}"
export HF_HUB_CACHE="${HF_HUB_CACHE:-/root/hf-cache/hub}"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"

echo
echo "=== Environment ==="
nvidia-smi || true
python - <<'PY'
import torch
print("torch:", torch.__version__)
print("cuda:", torch.version.cuda)
print("available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
    print("VRAM GiB:", torch.cuda.get_device_properties(0).total_memory / 2**30)
PY

echo
echo "=== 1. Install Phase13 experimental route ==="
python tools/install_phase13_flash.py

# Always preserve a partial archive if a later GPU gate fails.
trap 'python tools/package_phase13_results.py || true' EXIT

python -m pip install -e . --no-deps

# Force JIT rebuild with phase13_flash_paged.cu.
rm -rf .cache/torch_extensions/specdec_custom_kernels || true

echo
echo "=== 2. CUDA extension build smoke ==="
python - <<'PY'
from specdec.kernels.build import load
m = load()
needed = [
    "phase13_flash_paged_bf16",
    "phase13_flash_paged_vfp8",
]
missing = [x for x in needed if not hasattr(m, x)]
if missing:
    raise SystemExit("missing Phase13 APIs: " + repr(missing))
print("PHASE13_CUDA_EXTENSION: PASS")
PY

echo
echo "============================================================"
echo " 3. OPERATOR CORRECTNESS GATE"
echo "============================================================"
python -m specdec.engine.phase13_flash_operator_gate

echo
echo "============================================================"
echo " 4. FLASH-PAGED MICROBENCH q_len=1..4"
echo "============================================================"
python -m specdec.engine.phase13_flash_microbench \
  --contexts 512,2048,4096,8192 \
  --qlens 1,2,3,4 \
  --warmup 4 \
  --iters 30 \
  --repeats 3 \
  --outdir output/phase13_flash

echo
echo "============================================================"
echo " 5. REAL SPECDEC: direct_cuda vs flash_paged_cuda"
echo "============================================================"
python -m specdec.engine.phase13_flash_specdec \
  --contexts 2048,4096,8192 \
  --target-kvs base_bf16,v_fp8 \
  --repeats 3 \
  --steps 16 \
  --chunk 512 \
  --page-size 16 \
  --outdir output/phase13_flash

echo
echo "============================================================"
echo " 6. Package final results"
echo "============================================================"
python tools/package_phase13_results.py

# Prevent duplicate packaging by EXIT trap after successful final package.
trap - EXIT

echo
echo "============================================================"
echo " PHASE13_FLASH_ATTENTION_SUITE_PASS"
echo "============================================================"
echo "Archive:"
echo "  /workspace/SPECDEC_PHASE13_FLASH_ATTENTION_RESULTS_2026-10-04.zip"
echo
echo "Restore command after archiving, if desired:"
echo "  python tools/restore_phase13_flash.py"
