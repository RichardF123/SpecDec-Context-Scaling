#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import shutil
import time

REPO = Path("/workspace/SpecDec-feat-paged-attention-v1")
HERE = REPO / "payload"

EXPECTED = {
    "specdec/engine/model_self.py":
        "e81bef490e8bf43c29fe68f0e5977c178cc5a6f1240cc2c6b4f16c4d30bbff8a",
    "specdec/kernels/ops.py":
        "11de24331e8055a84b1d57538a458879f6214318bc6ee41eee607cd54313200f",
    "specdec/kernels/build.py":
        "defa2f5b7f23ba51618efdfc25ec2bccb2a3662625139ca51c550948654b4a65",
    "specdec/kernels/cuda/bind.cpp":
        "1462fdc1c0ac0eeeebe4e93bdb82839f78dd6aaaf1211fafa4859650aa298413",
}

CORE = list(EXPECTED)

NEW_FILES = [
    "specdec/kernels/cuda/phase13_flash_paged.cu",
    "specdec/engine/phase13_flash_operator_gate.py",
    "specdec/engine/phase13_flash_microbench.py",
    "specdec/engine/phase13_flash_specdec.py",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


if not (REPO / "pyproject.toml").exists():
    raise SystemExit(f"repo not found: {REPO}")

if not HERE.exists():
    raise SystemExit(
        "payload/ not found. Unzip the Phase13 suite into the repository root."
    )

model = REPO / "specdec/engine/model_self.py"
if "flash_paged_cuda" in model.read_text(encoding="utf-8"):
    print("PHASE13_INSTALL: already installed")
    raise SystemExit(0)

if not (REPO / "specdec/kernels/cuda/phase12_h2o_opt.cu").exists():
    raise SystemExit(
        "Phase13 expects the successful Phase12 experimental state "
        "(phase12_h2o_opt.cu is missing)."
    )

mismatch = []
for rel, expected in EXPECTED.items():
    path = REPO / rel
    if not path.exists():
        mismatch.append((rel, "MISSING", expected))
        continue
    actual = sha(path)
    if actual != expected:
        mismatch.append((rel, actual, expected))

if mismatch:
    print("PHASE13_INSTALL_ABORT: current core files are not the frozen Phase12 state.")
    for rel, actual, expected in mismatch:
        print(f"  {rel}")
        print(f"    current : {actual}")
        print(f"    expected: {expected}")
    print(
        "Do not force-overwrite. Preserve the current repo and inspect the "
        "difference before installing Phase13."
    )
    raise SystemExit(2)

stamp = time.strftime("%Y%m%d_%H%M%S")
backup = Path("/workspace") / f"SPECDEC_PHASE13_BACKUP_{stamp}"

for rel in CORE:
    src = REPO / rel
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

for rel in CORE + NEW_FILES:
    src = HERE / rel
    if not src.exists():
        raise SystemExit(f"payload missing {rel}")
    dst = REPO / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print("[installed]", rel)

(REPO / ".phase13_backup_path").write_text(
    str(backup), encoding="utf-8"
)

# Force custom extension rebuild against the new source set.
cache = REPO / ".cache/torch_extensions/specdec_custom_kernels"
if cache.exists():
    shutil.rmtree(cache)

print("PHASE13_INSTALL: PASS")
print("backup:", backup)
