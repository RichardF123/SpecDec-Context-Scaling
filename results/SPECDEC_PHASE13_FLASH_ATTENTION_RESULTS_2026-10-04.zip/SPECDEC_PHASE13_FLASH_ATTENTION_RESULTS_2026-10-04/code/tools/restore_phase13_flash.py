#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import shutil

REPO = Path("/workspace/SpecDec-feat-paged-attention-v1")
marker = REPO / ".phase13_backup_path"

if not marker.exists():
    raise SystemExit("No .phase13_backup_path found.")

backup = Path(marker.read_text(encoding="utf-8").strip())
if not backup.exists():
    raise SystemExit(f"backup directory missing: {backup}")

for src in backup.rglob("*"):
    if src.is_file():
        rel = src.relative_to(backup)
        dst = REPO / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print("[restored]", rel)

for rel in [
    "specdec/kernels/cuda/phase13_flash_paged.cu",
    "specdec/engine/phase13_flash_operator_gate.py",
    "specdec/engine/phase13_flash_microbench.py",
    "specdec/engine/phase13_flash_specdec.py",
]:
    p = REPO / rel
    if p.exists():
        p.unlink()
        print("[removed]", rel)

cache = REPO / ".cache/torch_extensions/specdec_custom_kernels"
if cache.exists():
    shutil.rmtree(cache)

print("PHASE13_RESTORE: PASS")
