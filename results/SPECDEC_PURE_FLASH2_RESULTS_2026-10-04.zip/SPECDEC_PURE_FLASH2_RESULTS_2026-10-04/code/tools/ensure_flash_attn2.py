#!/usr/bin/env python3
"""Install/validate the official FlashAttention-2 package."""
from __future__ import annotations
import os
import subprocess
import sys

PIN = "flash-attn==2.8.3.post1"


def validate():
    import torch
    import flash_attn
    from flash_attn import flash_attn_func, flash_attn_with_kvcache

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    major, minor = torch.cuda.get_device_capability()
    if major < 8:
        raise RuntimeError(
            f"FA2 CUDA path requires Ampere/Ada/Hopper class GPU; "
            f"got capability {major}.{minor}")
    print("flash_attn:", getattr(flash_attn, "__version__", "unknown"))
    print("torch:", torch.__version__)
    print("torch CUDA:", torch.version.cuda)
    print("GPU:", torch.cuda.get_device_name(0))
    print("capability:", torch.cuda.get_device_capability())
    print("flash_attn_func:", flash_attn_func)
    print("flash_attn_with_kvcache:", flash_attn_with_kvcache)


try:
    validate()
    print("OFFICIAL_FLASH_ATTN2: ALREADY_AVAILABLE")
    raise SystemExit(0)
except SystemExit:
    raise
except Exception as exc:
    print("[install] existing flash-attn unavailable:", repr(exc))

subprocess.check_call([
    sys.executable, "-m", "pip", "install",
    "-U", "packaging", "ninja", "wheel", "setuptools",
])

env = dict(os.environ)
# Prevent ninja from exploding host RAM on large cloud machines.
env.setdefault("MAX_JOBS", "4")

print("[install]", PIN)
subprocess.check_call([
    sys.executable, "-m", "pip", "install",
    PIN, "--no-build-isolation",
], env=env)

validate()
print("OFFICIAL_FLASH_ATTN2_INSTALL: PASS")
