#!/usr/bin/env bash
set -euo pipefail

REPO=/workspace/SpecDec-feat-paged-attention-v1
cd "$REPO"

echo "============================================================"
echo " SpecDec — PURE Official FlashAttention-2"
echo " NO paged KV in the FA2 backend"
echo " preallocated contiguous KV + flash_attn_with_kvcache"
echo "============================================================"

export HF_HOME="${HF_HOME:-/root/hf-cache}"
export HF_HUB_CACHE="${HF_HUB_CACHE:-/root/hf-cache/hub}"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"

echo
echo "=== Environment ==="
nvidia-smi
python - <<'PY'
import torch
print("torch:", torch.__version__)
print("torch CUDA:", torch.version.cuda)
print("available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
    print("capability:", torch.cuda.get_device_capability())
PY

echo
echo "=== 1. Install / validate official FlashAttention-2 ==="
python tools/ensure_flash_attn2.py

echo
echo "=== 2. Editable SpecDec install ==="
python -m pip install -e . --no-deps

echo
echo "============================================================"
echo " 3. OFFICIAL FA2 OPERATOR CORRECTNESS GATE"
echo "============================================================"
python -m specdec.engine.pure_flash2_operator_gate

echo
echo "============================================================"
echo " 4. PURE FA2 MICROBENCH q_len=1..4"
echo "============================================================"
python -m specdec.engine.pure_flash2_microbench \
  --contexts 512,2048,4096,8192 \
  --qlens 1,2,3,4 \
  --warmup 4 \
  --iters 20 \
  --repeats 3 \
  --outdir output/pure_flash2

echo
echo "============================================================"
echo " 5. REAL SPECDEC: paged_direct vs PURE official FA2"
echo "============================================================"
python -m specdec.engine.pure_flash2_specdec \
  --contexts 2048,4096,8192 \
  --repeats 3 \
  --steps 16 \
  --chunk 512 \
  --page-size 16 \
  --outdir output/pure_flash2

echo
echo "============================================================"
echo " 6. Package results"
echo "============================================================"
python tools/package_pure_flash2_results.py

echo
echo "============================================================"
echo " PURE_FLASH2_SUITE_COMPLETE"
echo "============================================================"
echo "Archive:"
echo "  /workspace/SPECDEC_PURE_FLASH2_RESULTS_2026-10-04.zip"
echo
echo "NOTE:"
echo "  This suite does not overwrite model_self.py/spec_dec.py/spec_cache.py."
echo "  The pure FA2 backend is installed only temporarily at runtime."
